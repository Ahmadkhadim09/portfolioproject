import { useEffect, useState } from "react";

const UNITS = [
  { key: "days", label: "Days" },
  { key: "hours", label: "Hours" },
  { key: "minutes", label: "Minutes" },
  { key: "seconds", label: "Seconds" },
] as const;

function diff(target: number) {
  const ms = Math.max(0, target - Date.now());
  return {
    days: Math.floor(ms / 86400000),
    hours: Math.floor(ms / 3600000) % 24,
    minutes: Math.floor(ms / 60000) % 60,
    seconds: Math.floor(ms / 1000) % 60,
  };
}

export function Countdown({ date }: { date: string }) {
  const target = new Date(date).getTime();
  const [time, setTime] = useState(() => diff(target));
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const id = setInterval(() => setTime(diff(target)), 1000);
    return () => clearInterval(id);
  }, [target]);

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 sm:gap-6">
      {UNITS.map(({ key, label }) => (
        <div
          key={key}
          className="panel-royal arch-top flex flex-col items-center px-4 py-6 sm:py-8"
        >
          <span className="jali pointer-events-none absolute inset-0" aria-hidden />
          <span className="font-display text-4xl leading-none text-gold-gradient sm:text-5xl">
            {mounted ? String(time[key]).padStart(2, "0") : "--"}
          </span>
          <span className="mt-3 text-[0.65rem] uppercase tracking-[0.35em] text-muted-foreground">
            {label}
          </span>
        </div>
      ))}
    </div>
  );
}
