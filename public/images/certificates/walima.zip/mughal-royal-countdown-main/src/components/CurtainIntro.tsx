import { useEffect, useState } from "react";

/**
 * Full-screen velvet-curtain entry overlay.
 * Guest taps the gold crest, curtains part, invitation is revealed.
 */
export function CurtainIntro({ initials = "Z & A" }: { initials?: string }) {
  const [opening, setOpening] = useState(false);
  const [gone, setGone] = useState(false);

  useEffect(() => {
    if (!opening) return;
    document.body.dataset.revealed = "true";
    const t = setTimeout(() => setGone(true), 2200);
    return () => clearTimeout(t);
  }, [opening]);

  useEffect(() => {
    document.body.style.overflow = opening ? "" : "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, [opening]);

  if (gone) return null;

  return (
    <div
      className="fixed inset-0 z-50"
      style={{ pointerEvents: opening ? "none" : "auto" }}
      aria-hidden={opening}
    >
      <div className={`curtain-panel curtain-left ${opening ? "is-open" : ""}`} />
      <div className={`curtain-panel curtain-right ${opening ? "is-open" : ""}`} />

      <div
        className={`absolute inset-0 flex flex-col items-center justify-center px-6 text-center transition-opacity duration-500 ${
          opening ? "opacity-0" : "opacity-100"
        }`}
      >
        <button
          type="button"
          onClick={() => setOpening(true)}
          className="group flex flex-col items-center focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          aria-label="Open the invitation"
        >
          <span className="crest-ring flex h-32 w-32 items-center justify-center rounded-full sm:h-40 sm:w-40">
            <span className="font-display text-4xl text-gold-gradient sm:text-5xl">
              {initials}
            </span>
          </span>
          <span className="mt-8 text-[0.6rem] uppercase tracking-[0.5em] text-primary shimmer sm:text-xs">
            Tap to open
          </span>
        </button>
      </div>
    </div>
  );
}
