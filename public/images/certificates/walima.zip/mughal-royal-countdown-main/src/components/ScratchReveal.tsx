import { useEffect, useRef, useState } from "react";

/**
 * Scratch-off card: guests rub away a gold foil layer to reveal the wedding date.
 */
export function ScratchReveal({
  title,
  subtitle,
}: {
  title: string;
  subtitle: string;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [revealed, setRevealed] = useState(false);
  const drawing = useRef(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;

    const paint = () => {
      const { width, height } = wrap.getBoundingClientRect();
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      const grad = ctx.createLinearGradient(0, 0, width, height);
      grad.addColorStop(0, "#7c5a1e");
      grad.addColorStop(0.45, "#e0bd6a");
      grad.addColorStop(0.7, "#a67c2b");
      grad.addColorStop(1, "#d8b25f");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
      ctx.fillStyle = "rgba(60,35,10,0.35)";
      ctx.font = "600 11px system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.letterSpacing = "6px";
      ctx.fillText("SCRATCH TO REVEAL", width / 2, height / 2 + 4);
    };

    paint();
    window.addEventListener("resize", paint);
    return () => window.removeEventListener("resize", paint);
  }, []);

  const scratch = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas || revealed) return;
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.globalCompositeOperation = "destination-out";
    ctx.beginPath();
    ctx.arc(clientX - rect.left, clientY - rect.top, 26, 0, Math.PI * 2);
    ctx.fill();

    const { width, height } = canvas;
    const data = ctx.getImageData(0, 0, width, height).data;
    let clear = 0;
    for (let i = 3; i < data.length; i += 4 * 24) if (data[i] === 0) clear++;
    if (clear / (data.length / (4 * 24)) > 0.45) setRevealed(true);
  };

  return (
    <div className="mx-auto max-w-md">
      <div
        ref={wrapRef}
        className="panel-royal arch-top relative overflow-hidden px-6 py-10 text-center"
      >
        <span className="jali pointer-events-none absolute inset-0" aria-hidden />
        <div className="relative">
          <p className="font-display text-3xl text-gold-gradient sm:text-4xl">{title}</p>
          <p className="mt-3 text-xs uppercase tracking-[0.35em] text-muted-foreground">
            {subtitle}
          </p>
        </div>
        {!revealed && (
          <canvas
            ref={canvasRef}
            className="absolute inset-0 h-full w-full cursor-pointer touch-none"
            onPointerDown={(e) => {
              drawing.current = true;
              scratch(e.clientX, e.clientY);
            }}
            onPointerMove={(e) => drawing.current && scratch(e.clientX, e.clientY)}
            onPointerUp={() => (drawing.current = false)}
            onPointerLeave={() => (drawing.current = false)}
          />
        )}
      </div>
      <button
        type="button"
        onClick={() => setRevealed(true)}
        className={`mx-auto mt-3 block text-[0.6rem] uppercase tracking-[0.3em] text-muted-foreground underline-offset-4 hover:text-primary ${
          revealed ? "invisible" : ""
        }`}
      >
        Reveal instead
      </button>
    </div>
  );
}
