export function VenueMap({
  venue,
  address,
  query,
}: {
  venue: string;
  address: string;
  query: string;
}) {
  const encoded = encodeURIComponent(query);
  return (
    <div className="panel-royal arch-top overflow-hidden">
      <div className="relative px-7 pt-8 text-center">
        <h3 className="font-display text-3xl text-primary">{venue}</h3>
        <p className="mt-2 text-sm text-foreground/90">{address}</p>
      </div>
      <div className="mt-6 aspect-[4/3] w-full sm:aspect-[16/9]">
        <iframe
          title={`Map to ${venue}`}
          src={`https://www.google.com/maps?q=${encoded}&output=embed`}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          className="h-full w-full border-0 grayscale-[35%]"
        />
      </div>
      <div className="px-7 py-6 text-center">
        <a
          href={`https://www.google.com/maps/search/?api=1&query=${encoded}`}
          target="_blank"
          rel="noreferrer"
          className="inline-block rounded-sm border border-primary px-6 py-3 text-[0.65rem] uppercase tracking-[0.3em] text-primary transition hover:bg-primary hover:text-primary-foreground"
        >
          Open in Maps
        </a>
      </div>
    </div>
  );
}
