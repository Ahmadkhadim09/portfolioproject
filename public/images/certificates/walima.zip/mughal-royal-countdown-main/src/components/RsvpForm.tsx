import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { rsvpSchema, submitRsvp } from "@/lib/rsvp.functions";

export function RsvpForm() {
  const send = useServerFn(submitRsvp);
  const [attending, setAttending] = useState(true);
  const [pending, setPending] = useState(false);
  const [done, setDone] = useState(false);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const parsed = rsvpSchema.safeParse({
      name: String(form.get("name") ?? ""),
      email: String(form.get("email") ?? ""),
      attending,
      guests: Number(form.get("guests") ?? 1),
      message: String(form.get("message") ?? ""),
    });

    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Please check your details");
      return;
    }

    setPending(true);
    try {
      await send({ data: parsed.data });
      setDone(true);
      toast.success(
        attending ? "Your seat in the darbar is reserved." : "Thank you for letting us know.",
      );
    } catch {
      toast.error("We couldn't record your RSVP. Please try again.");
    } finally {
      setPending(false);
    }
  }

  if (done) {
    return (
      <div className="panel-royal arch-top px-8 py-14 text-center">
        <span className="jali pointer-events-none absolute inset-0" aria-hidden />
        <p className="font-display text-3xl text-gold-gradient">Shukriya</p>
        <p className="mt-4 text-sm text-muted-foreground">
          Your response has been inscribed in the royal register.
        </p>
      </div>
    );
  }

  const fieldClass =
    "w-full rounded-sm border border-border bg-background/50 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/60 outline-none transition focus:border-primary";
  const labelClass = "mb-2 block text-[0.65rem] uppercase tracking-[0.3em] text-muted-foreground";

  return (
    <form onSubmit={onSubmit} className="panel-royal arch-top px-6 py-10 sm:px-10">
      <span className="jali pointer-events-none absolute inset-0" aria-hidden />
      <div className="relative space-y-6">
        <div>
          <label className={labelClass} htmlFor="name">
            Your name
          </label>
          <input id="name" name="name" maxLength={100} required className={fieldClass} />
        </div>
        <div>
          <label className={labelClass} htmlFor="email">
            Email
          </label>
          <input
            id="email"
            name="email"
            type="email"
            maxLength={255}
            required
            className={fieldClass}
          />
        </div>

        <div>
          <span className={labelClass}>Will you join us?</span>
          <div className="grid grid-cols-2 gap-3">
            {[
              { value: true, label: "Joyfully accept" },
              { value: false, label: "Regretfully decline" },
            ].map((option) => (
              <button
                key={String(option.value)}
                type="button"
                onClick={() => setAttending(option.value)}
                className={`rounded-sm border px-4 py-3 text-xs uppercase tracking-[0.2em] transition ${
                  attending === option.value
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border text-muted-foreground hover:border-primary/60"
                }`}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>

        {attending && (
          <div>
            <label className={labelClass} htmlFor="guests">
              Number in your party
            </label>
            <input
              id="guests"
              name="guests"
              type="number"
              min={1}
              max={10}
              defaultValue={1}
              className={fieldClass}
            />
          </div>
        )}

        <div>
          <label className={labelClass} htmlFor="message">
            A note for the couple
          </label>
          <textarea id="message" name="message" rows={3} maxLength={1000} className={fieldClass} />
        </div>

        <button
          type="submit"
          disabled={pending}
          className="w-full rounded-sm bg-primary px-6 py-4 text-xs uppercase tracking-[0.35em] text-primary-foreground transition hover:opacity-90 disabled:opacity-60"
        >
          {pending ? "Sending…" : "Send RSVP"}
        </button>
      </div>
    </form>
  );
}
