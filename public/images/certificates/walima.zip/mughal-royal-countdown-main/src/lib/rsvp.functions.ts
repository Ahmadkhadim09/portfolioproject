import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export const rsvpSchema = z.object({
  name: z.string().trim().min(1, "Please share your name").max(100, "Name is too long"),
  email: z.string().trim().email("Enter a valid email").max(255),
  attending: z.boolean(),
  guests: z.number().int().min(0).max(10),
  message: z.string().trim().max(1000, "Message is too long").optional(),
});

export type RsvpInput = z.infer<typeof rsvpSchema>;

export const submitRsvp = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => rsvpSchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("rsvps").insert({
      name: data.name,
      email: data.email,
      attending: data.attending,
      guests: data.attending ? data.guests : 0,
      message: data.message || null,
    });
    if (error) throw new Error("We couldn't record your RSVP. Please try again.");
    return { ok: true as const };
  });
