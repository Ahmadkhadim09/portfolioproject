import { createFileRoute } from "@tanstack/react-router";
import { Countdown } from "@/components/Countdown";
import { RsvpForm } from "@/components/RsvpForm";
import { CurtainIntro } from "@/components/CurtainIntro";
import { ScratchReveal } from "@/components/ScratchReveal";
import { VenueMap } from "@/components/VenueMap";
import heroImage from "@/assets/walima-hero.jpg";
import archImage from "@/assets/mughal-arch.png";

const WEDDING_DATE = "2026-10-31T19:00:00+05:00";

const VENUE_QUERY = "Bella Rose Event Complex, Bedian Road, Lahore";

const CONTACTS = [
  { name: "Muneeb Kashif", phone: "0333-4600488" },
  { name: "Moiz Kashif", phone: "0321-4414839" },
];

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Owais Weds Minahil — Baraat, 31 October 2026, Lahore" },
      {
        name: "description",
        content:
          "Join us for the wedding of Owais & Minahil. Baraat on 31 October 2026, 7 PM onwards at Bella Rose Event Complex, Bedian Road, Lahore. RSVP online.",
      },
      { property: "og:title", content: "Owais Weds Minahil — 31 October 2026" },
      {
        property: "og:description",
        content:
          "Baraat at Bella Rose Event Complex, Bedian Road, Lahore. 7 PM onwards. Kindly RSVP.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Invitation,
});

function Ornament() {
  return (
    <div className="flex items-center justify-center gap-4 py-2" aria-hidden>
      <span className="h-px w-16 bg-primary/40 sm:w-28" />
      <span className="shimmer text-primary">✦</span>
      <span className="h-px w-16 bg-primary/40 sm:w-28" />
    </div>
  );
}

function Petals() {
  return (
    <div className="petal-field pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      {Array.from({ length: 14 }).map((_, i) => (
        <span key={i} className={`petal petal-${i % 7}`} />
      ))}
    </div>
  );
}

function AmbientBackground() {
  return (
    <>
      <div className="bg-effects" aria-hidden>
        {Array.from({ length: 8 }).map((_, i) => (
          <span key={i} className={`spark spark-${i}`} />
        ))}
      </div>
      <div className="bg-vignette" aria-hidden />
    </>
  );
}

function Invitation() {
  return (
    <>
      <CurtainIntro initials="O & M" />
      <AmbientBackground />
      <main className="relative z-10 mx-auto max-w-5xl px-5 pb-24 sm:px-8">
        <section className="reveal reveal-1 relative pt-10 text-center sm:pt-16">
          <div className="panel-royal arch-top overflow-hidden">
            <img
              src={heroImage}
              alt="Mughal miniature painting of an opulent walima banquet hall with chandeliers and marigold garlands"
              width={1536}
              height={1024}
              className="hero-kenburns h-[46vh] w-full object-cover opacity-90 sm:h-[60vh]"
            />
            <div className="absolute inset-0 bg-background/45" />
            <div className="hero-sheen pointer-events-none absolute inset-0" aria-hidden />
            <Petals />
            <div className="absolute inset-0 flex flex-col items-center justify-center px-6">

              <p className="float-soft text-[0.6rem] uppercase tracking-[0.45em] text-primary sm:text-xs">
                We joyfully invite you to celebrate the wedding of
              </p>
              <h1 className="mt-5 font-display text-5xl leading-tight text-gold-gradient sm:text-7xl">
                <span className="rise-in rise-1 block">Owais</span>
                <span className="rise-in rise-2 block text-primary/70 text-3xl sm:text-5xl">&</span>
                <span className="rise-in rise-3 block">Minahil</span>
              </h1>
              <Ornament />
              <p className="rise-in rise-4 max-w-md text-sm text-foreground/90 sm:text-base">
                Minahil, daughter of Kashif Shuja and Rabia Kashif
              </p>
              <p className="rise-in rise-5 mt-4 font-display text-xl text-primary sm:text-2xl">
                31 October 2026 · Lahore
              </p>
            </div>
          </div>
        </section>

        <section className="reveal reveal-2 pt-20" aria-labelledby="scratch-heading">
          <h2
            id="scratch-heading"
            className="text-center text-[0.65rem] uppercase tracking-[0.45em] text-muted-foreground"
          >
            Scratch to reveal the date
          </h2>
          <div className="mt-8">
            <ScratchReveal title="31 October 2026" subtitle="Baraat · 7 PM Onwards" />
          </div>
        </section>

        <section className="reveal reveal-2 pt-20" aria-labelledby="countdown-heading">
          <h2
            id="countdown-heading"
            className="text-center text-[0.65rem] uppercase tracking-[0.45em] text-muted-foreground"
          >
            The celebration begins in
          </h2>
          <div className="mt-8">
            <Countdown date={WEDDING_DATE} />
          </div>
        </section>

        <section className="reveal reveal-3 pt-24" aria-labelledby="events-heading">
          <h2 id="events-heading" className="text-center font-display text-4xl text-gold-gradient">
            Baraat
          </h2>
          <Ornament />
          <div className="mx-auto mt-8 max-w-2xl">
            <article className="panel-royal arch-top px-7 py-10 text-center">
              <span className="jali pointer-events-none absolute inset-0" aria-hidden />
              <div className="relative">
                <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
                  31st October 2026 · 7 PM Onwards
                </p>
                <p className="mt-4 font-display text-3xl text-primary">
                  Bella Rose Event Complex
                </p>
                <p className="mt-2 text-sm text-foreground/90">Bedian Road, Lahore</p>
              </div>
            </article>
          </div>
        </section>

        <section className="reveal reveal-3 pt-20" aria-labelledby="map-heading">
          <h2 id="map-heading" className="text-center font-display text-4xl text-gold-gradient">
            Find Us
          </h2>
          <Ornament />
          <div className="mx-auto mt-8 max-w-3xl">
            <VenueMap
              venue="Bella Rose Event Complex"
              address="Bedian Road, Lahore"
              query={VENUE_QUERY}
            />
          </div>
        </section>

        <section className="reveal reveal-4 pt-24" aria-labelledby="rsvp-heading" id="rsvp">
          <img
            src={archImage}
            alt=""
            aria-hidden
            loading="lazy"
            width={1024}
            height={1024}
            className="mx-auto mb-6 w-40 opacity-60 sm:w-52"
          />
          <h2 id="rsvp-heading" className="text-center font-display text-4xl text-gold-gradient">
            R.S.V.P
          </h2>
          <div className="mx-auto mt-6 flex max-w-xl flex-wrap justify-center gap-4">
            {CONTACTS.map((c) => (
              <a
                key={c.phone}
                href={`tel:${c.phone.replace(/-/g, "")}`}
                className="rounded-sm border border-border px-5 py-3 text-center transition hover:border-primary"
              >
                <span className="block text-sm text-foreground/90">{c.name}</span>
                <span className="mt-1 block text-xs tracking-[0.2em] text-primary">{c.phone}</span>
              </a>
            ))}
          </div>
          <div className="mx-auto mt-10 max-w-xl">
            <RsvpForm />
          </div>
        </section>

        <footer className="reveal reveal-5 pt-20 text-center">
          <Ornament />
          <p className="font-display text-2xl text-primary">Owais &amp; Minahil</p>
          <p className="mt-2 text-xs uppercase tracking-[0.3em] text-muted-foreground">
            Lahore · 31 October 2026
          </p>
        </footer>
      </main>
    </>
  );
}
